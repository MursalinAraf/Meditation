const app = () => {

	const song = document.querySelector('.song')
	const play = document.querySelector('.play');
	const outline = document.querySelector('.moving-outline circle');
	const video = document.querySelector('.vid-container video');

	//sounds

	const sound = document.querySelectorAll('.sound-picker button');
	const timedisplay = document.querySelector('.time-display');
	const timeselect = document.querySelectorAll('.time-select button');
	
	const OutlineLength = outline.getTotalLength();
	console.log(OutlineLength);

	let fakeduration = 600;

	outline.style.strokeDasharray = OutlineLength;
	outline.style.strokeDashoffset = OutlineLength;

	sound.forEach(sound => {
		sound.addEventListener('click',function(){
			song.src = this.getAttribute('data-sound');
			video.src = this.getAttribute('data-video');
			checkPlaying(song);
		});
	});

	//play sound
	play.addEventListener('click', () => {
		checkPlaying(song);
	});

	timeselect.forEach(option =>
	{
		option.addEventListener('click',function (){
			fakeduration = this.getAttribute('data-time');
			timedisplay.textContent = `${Math.floor(fakeduration / 60)}:${Math.floor(fakeduration % 60)}`;
		}); 

	});

	const checkPlaying = () => {
		if (song.paused) {
			song.play();
			video.play();
			play.src = "./svg/pause.svg";
		}
		else{
			song.pause();
			video.pause();
			play.src = "./svg/play.svg";
		}
	}
	song.ontimeupdate = () =>{
		let currentTime = song.currentTime;
		let elapsed = fakeduration - currentTime;
		let second = Math.floor(elapsed % 60);
		let min = Math.floor(elapsed/60);

		if (currentTime >= fakeduration) {
			song.pause();
			song.currentTime = 0;
			play.src ="./svg/play.svg";
			video.pause();
		}

		let progress = OutlineLength - (currentTime/fakeduration)*OutlineLength;
	outline.style.strokeDashoffset = progress; 

	timedisplay.textContent = `${min}:${second}`;
	};


	};

	app();